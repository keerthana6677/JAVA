import java.util.*;

/** Task 3 alternative: linear scan vs per-floor free-slot stacks (F=5, S=100). */
public class FreeStackBench {
    static final int F = 5, S = 100;

    static class Scan {
        String[][] slots = new String[F][S];
        int[] allocate(String v) {
            for (int f = 0; f < F; f++) for (int s = 0; s < S; s++)
                if (slots[f][s] == null) { slots[f][s] = v; return new int[]{f, s}; }
            return null;
        }
        boolean release(int f, int s) {
            if (f < 0 || f >= F || s < 0 || s >= S || slots[f][s] == null) return false;
            slots[f][s] = null; return true;
        }
    }
    static class Stack {
        boolean[] occ = new boolean[F * S];
        int[] freeCount = new int[F];
        ArrayDeque<Integer>[] free;
        @SuppressWarnings("unchecked") Stack() {
            free = new ArrayDeque[F];
            for (int f = 0; f < F; f++) {
                free[f] = new ArrayDeque<>(); freeCount[f] = S;
                for (int s = S - 1; s >= 0; s--) free[f].push(s);
            }
        }
        int[] allocate() {
            for (int f = 0; f < F; f++) if (freeCount[f] > 0) {
                int s = free[f].pop(); freeCount[f]--; occ[f * S + s] = true; return new int[]{f, s};
            }
            return null;
        }
        boolean release(int f, int s) {
            if (f < 0 || f >= F || s < 0 || s >= S || !occ[f * S + s]) return false;
            occ[f * S + s] = false; free[f].push(s); freeCount[f]++; return true;
        }
    }

    public static void main(String[] args) {
        int cycles = 2_000_000;
        for (int filled : new int[]{0, 250, 499}) {
            Scan a = new Scan(); Stack b = new Stack();
            for (int i = 0; i < filled; i++) { a.allocate("V" + i); b.allocate(); }
            long sink = 0;
            for (int w = 0; w < 300_000; w++) {            // warm-up
                int[] p = a.allocate("X"); a.release(p[0], p[1]);
                int[] q = b.allocate(); b.release(q[0], q[1]);
            }
            long t0 = System.nanoTime();
            for (int i = 0; i < cycles; i++) { int[] p = a.allocate("X"); sink += p[1]; a.release(p[0], p[1]); }
            long t1 = System.nanoTime();
            for (int i = 0; i < cycles; i++) { int[] q = b.allocate(); sink += q[1]; b.release(q[0], q[1]); }
            long t2 = System.nanoTime();
            System.out.printf("occupied=%3d/500  scan: %5d ns/cycle   stack: %5d ns/cycle%n",
                    filled, (t1 - t0) / cycles, (t2 - t1) / cycles);
            if (sink == 1) System.out.println();
        }
    }
}
