package parking.service;

import parking.model.*;
import java.util.HashMap;
import java.util.Map;

/** One parking facility: jagged slot array + HashMap of active tickets keyed by registration number. */
public class ParkingFacility {
    private final String[][] slots;                       // jagged: floors may differ in size
    private final int[] freePerFloor;
    private final Map<String, ParkingTicket> active = new HashMap<>();
    private double totalCollected;

    public ParkingFacility(int[] slotsPerFloor) {
        if (slotsPerFloor == null || slotsPerFloor.length == 0) throw new IllegalArgumentException("no floors");
        slots = new String[slotsPerFloor.length][];
        freePerFloor = new int[slotsPerFloor.length];
        for (int f = 0; f < slotsPerFloor.length; f++) {
            if (slotsPerFloor[f] <= 0) throw new IllegalArgumentException("floor " + f + " needs at least 1 slot");
            slots[f] = new String[slotsPerFloor[f]];
            freePerFloor[f] = slotsPerFloor[f];
        }
    }

    public ParkingTicket enter(Vehicle v, UserType user, boolean monthlyPass, int entryMin) {
        return enter(v, user, monthlyPass ? new MonthlyPass(36500) : NoPass.INSTANCE, entryMin);
    }

    public ParkingTicket enter(Vehicle v, UserType user, Pass pass, int entryMin) {
        if (active.containsKey(v.getRegNo()))
            throw new IllegalArgumentException("duplicate registration: " + v.getRegNo());
        int[] pos = allocate(v.getRegNo());
        if (pos == null) throw new IllegalStateException("facility full");
        ParkingTicket t = new ParkingTicket(v, user, pass, pos[0], pos[1], entryMin);
        active.put(v.getRegNo(), t);
        return t;
    }

    private int[] allocate(String regNo) {
        for (int f = 0; f < slots.length; f++) {
            if (freePerFloor[f] == 0) continue;           // skip a full floor
            for (int s = 0; s < slots[f].length; s++) {
                if (slots[f][s] == null) {
                    slots[f][s] = regNo; freePerFloor[f]--;
                    return new int[]{f, s};               // stop at first free slot
                }
            }
        }
        return null;
    }

    public boolean release(int floor, int slot) {
        if (floor < 0 || floor >= slots.length || slot < 0 || slot >= slots[floor].length) return false;
        if (slots[floor][slot] == null) return false;
        active.remove(slots[floor][slot]);
        slots[floor][slot] = null; freePerFloor[floor]++;
        return true;
    }

    public Bill exit(String regNo, int exitMin, int kWh) {
        ParkingTicket t = active.get(regNo);
        if (t == null) throw new IllegalArgumentException("no active ticket for " + regNo);
        Vehicle v = t.getVehicle();
        double parking = t.getPass().parkingFee(v, t.getEntryMin(), exitMin);
        double charging = 0;
        if (kWh > 0) {
            if (!(v instanceof Chargeable c)) throw new IllegalArgumentException(regNo + " cannot be charged");
            charging = c.chargingFee(kWh);
        }
        release(t.getFloor(), t.getSlot());
        Bill b = new Bill(t.getTicketNo(), regNo, parking, charging);
        totalCollected += b.total();
        return b;
    }

    public int freeSlots() { int n = 0; for (int x : freePerFloor) n += x; return n; }
    public int activeCount() { return active.size(); }
    public double getTotalCollected() { return totalCollected; }
}
