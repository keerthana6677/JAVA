package parking.model;

/** Abstraction for any pass: decides how much of a stay is actually charged. */
public interface Pass {
    boolean allowedFor(UserType user);
    double parkingFee(Vehicle v, int entryMin, int exitMin);
    String label();
}
