package parking.model;

public final class OneDayPass extends PeriodPass {
    public OneDayPass(int day) { super(day * Vehicle.MINUTES_PER_DAY, (day + 1) * Vehicle.MINUTES_PER_DAY); }
    @Override public boolean allowedFor(UserType u) { return u == UserType.VISITOR; }
    @Override public String label() { return "one-day pass"; }
}
