package parking.model;

/** Issued at entry. Ticket numbers come from a static counter and are never reused. */
public final class ParkingTicket {
    private static long counter = 1000;                  // shared by ALL facilities

    private final long ticketNo;
    private final Vehicle vehicle;
    private final UserType user;
    private final Pass pass;
    private final int floor, slot, entryMin;

    public ParkingTicket(Vehicle v, UserType u, int floor, int slot, int entryMin) {
        this(v, u, false, floor, slot, entryMin);        // constructor chaining
    }

    public ParkingTicket(Vehicle v, UserType u, boolean monthlyPass, int floor, int slot, int entryMin) {
        this(v, u, monthlyPass ? new MonthlyPass(36500) : NoPass.INSTANCE, floor, slot, entryMin);
    }

    public ParkingTicket(Vehicle v, UserType u, Pass pass, int floor, int slot, int entryMin) {
        if (v == null || u == null || pass == null) throw new IllegalArgumentException("vehicle and user type are required");
        if (floor < 0 || slot < 0 || entryMin < 0) throw new IllegalArgumentException("invalid ticket data");
        this.ticketNo = nextNumber();
        this.vehicle = v; this.user = u;
        this.pass = pass.allowedFor(u) ? pass : NoPass.INSTANCE;   // ineligible pass is ignored
        this.floor = floor; this.slot = slot; this.entryMin = entryMin;
    }

    /** Copy constructor: re-issues a duplicate ticket with the SAME number. */
    public ParkingTicket(ParkingTicket o) {
        this.ticketNo = o.ticketNo; this.vehicle = o.vehicle; this.user = o.user;
        this.pass = o.pass; this.floor = o.floor; this.slot = o.slot; this.entryMin = o.entryMin;
    }

    private static synchronized long nextNumber() { return ++counter; }

    public long getTicketNo() { return ticketNo; }
    public Vehicle getVehicle() { return vehicle; }
    public UserType getUser() { return user; }
    public Pass getPass() { return pass; }
    public int getFloor() { return floor; }
    public int getSlot() { return slot; }
    public int getEntryMin() { return entryMin; }

    @Override public String toString() {
        return "Ticket#" + ticketNo + " " + vehicle + " " + user + " slot=(" + floor + "," + slot + ") entry=" + entryMin;
    }
}
