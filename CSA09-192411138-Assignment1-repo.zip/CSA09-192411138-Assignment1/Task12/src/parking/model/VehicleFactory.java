package parking.model;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

/** Registry-based factory: a new vehicle type is one new class + one register() line. */
public final class VehicleFactory {
    private static final Map<String, Function<String, Vehicle>> REGISTRY = new HashMap<>();
    static {
        register("TWOWHEELER", TwoWheeler::new);
        register("CAR", Car::new);
        register("EV", ElectricCar::new);
        register("EBIKE", EBike::new);
        register("VAN", DeliveryVan::new);
    }
    private VehicleFactory() { }
    public static void register(String type, Function<String, Vehicle> maker) { REGISTRY.put(type, maker); }
    public static Vehicle create(String type, String regNo) {
        if (type == null) throw new IllegalArgumentException("vehicle type missing");
        Function<String, Vehicle> maker = REGISTRY.get(type.trim().toUpperCase());
        if (maker == null) throw new IllegalArgumentException("unknown vehicle type: " + type);
        return maker.apply(regNo);
    }
}
