package parking.model;

/** A pass that makes parking free inside the window [startMin, endMin); outside it normal fees apply. */
public abstract class PeriodPass implements Pass {
    private final int startMin, endMin;
    protected PeriodPass(int startMin, int endMin) {
        if (startMin < 0 || endMin <= startMin) throw new IllegalArgumentException("invalid pass period");
        this.startMin = startMin; this.endMin = endMin;
    }
    @Override public double parkingFee(Vehicle v, int entryMin, int exitMin) {
        double fee = 0;
        int beforeEnd = Math.min(exitMin, startMin);
        if (entryMin < beforeEnd) fee += v.calculateFee(entryMin, beforeEnd);      // part before the pass starts
        int afterStart = Math.max(entryMin, endMin);
        if (exitMin > afterStart) fee += v.calculateFee(afterStart, exitMin);      // part after the pass ends
        return fee;
    }
}
