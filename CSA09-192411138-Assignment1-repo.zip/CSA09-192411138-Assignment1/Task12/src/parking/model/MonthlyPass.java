package parking.model;

public final class MonthlyPass extends PeriodPass {
    public MonthlyPass(int validTillDay) { super(0, (validTillDay + 1) * Vehicle.MINUTES_PER_DAY); }
    @Override public boolean allowedFor(UserType u) { return u.isPassEligible(); }
    @Override public String label() { return "monthly pass"; }
}
