package parking.model;

public final class NoPass implements Pass {
    public static final NoPass INSTANCE = new NoPass();
    private NoPass() { }
    @Override public boolean allowedFor(UserType u) { return true; }
    @Override public double parkingFee(Vehicle v, int entryMin, int exitMin) { return v.calculateFee(entryMin, exitMin); }
    @Override public String label() { return "no pass"; }
}
