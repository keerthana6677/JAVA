package parking.model;

/** Delivery van: car rate, doubled for every started hour that begins between 09:00 and 17:00. */
public class DeliveryVan extends Car {
    private static final int PEAK_START = 9 * 60, PEAK_END = 17 * 60;
    public DeliveryVan(String regNo) { super(regNo); }
    @Override public double calculateFee(int entryMin, int exitMin) {
        if (exitMin < entryMin) throw new IllegalArgumentException("exit before entry");
        int hours = (exitMin - entryMin + 59) / 60;
        double fee = 0;
        for (int h = 0; h < hours; h++) {
            int clock = (entryMin + h * 60) % MINUTES_PER_DAY;
            boolean peak = clock >= PEAK_START && clock < PEAK_END;
            fee += peak ? 2 * ratePerHour() : ratePerHour();
        }
        return fee;
    }
}
