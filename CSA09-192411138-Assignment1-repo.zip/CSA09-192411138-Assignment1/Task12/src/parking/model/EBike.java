package parking.model;

/** E-bike: flat fee per visit. */
public class EBike extends Vehicle {
    public static final double FLAT_FEE = 20;
    public EBike(String regNo) { super(regNo); }
    @Override protected double ratePerHour() { return 0; }          // not used: flat fee
    @Override public double calculateFee(int minutes) {
        if (minutes < 0) throw new IllegalArgumentException("duration cannot be negative: " + minutes);
        return minutes == 0 ? 0 : FLAT_FEE;
    }
}
