package parking.app;

import parking.model.*;
import parking.service.ParkingFacility;
import java.util.function.Supplier;

/** Task 12: tests for e-bike, delivery van, one-day pass and the 5-floor jagged facility. */
public class Task12Tests {
    static int pass = 0, total = 0;
    static void check(String id, String what, String expected, Supplier<String> actual) {
        String got;
        try { got = actual.get(); } catch (RuntimeException e) { got = e.getClass().getSimpleName() + ": " + e.getMessage(); }
        boolean ok = expected.equals(got); total++; if (ok) pass++;
        System.out.printf("%-4s %-44s | %-32s | %-32s | %s%n", id, what, expected, got, ok ? "PASS" : "FAIL");
    }
    static String f(double d) { return String.format("%.1f", d); }
    static String van(int in, int out) { return f(new DeliveryVan("TN40V1").calculateFee(in, out)); }
    static String bill(Vehicle v, UserType u, Pass p, int in, int out, int kWh) {
        ParkingFacility fac = new ParkingFacility(new int[]{2});
        fac.enter(v, u, p, in); return f(fac.exit(v.getRegNo(), out, kWh).total());
    }

    public static void main(String[] args) {
        System.out.printf("%-4s %-44s | %-32s | %-32s | %s%n", "ID", "Test", "Expected", "Actual", "Result");
        System.out.println("-".repeat(130));
        check("V1", "Van 10:00-12:00 (2 peak hours)", "120.0", () -> van(600, 720));
        check("V2", "Van 16:30-18:00 (peak + off-peak hour)", "90.0", () -> van(990, 1080));
        check("V3", "Van 17:00-18:00 (17:00 is off-peak)", "30.0", () -> van(1020, 1080));
        check("V4", "Van 09:00-10:00 (09:00 is peak)", "60.0", () -> van(540, 600));
        check("V5", "Van 08:30-09:30 (starts off-peak)", "30.0", () -> van(510, 570));
        check("V6", "Van zero minutes", "0.0", () -> van(600, 600));
        check("E1", "E-bike 20 min (flat)", "20.0", () -> f(new EBike("TN41E1").calculateFee(20)));
        check("E2", "E-bike 300 min (still flat)", "20.0", () -> f(new EBike("TN41E1").calculateFee(300)));
        check("E3", "E-bike zero minutes", "0.0", () -> f(new EBike("TN41E1").calculateFee(0)));
        check("P1", "Visitor car, one-day pass, same day", "0.0", () -> bill(new Car("TN42P1"), UserType.VISITOR, new OneDayPass(0), 540, 1000, 0));
        check("P2", "One-day pass, stay runs 2 h past midnight", "60.0", () -> bill(new Car("TN42P2"), UserType.VISITOR, new OneDayPass(0), 1380, 1560, 0));
        check("P3", "One-day pass given to staff is ignored", "90.0", () -> bill(new Car("TN42P3"), UserType.STAFF, new OneDayPass(0), 0, 130, 0));
        check("P4", "Monthly pass expired (1 h after expiry)", "30.0", () -> bill(new Car("TN42P4"), UserType.STAFF, new MonthlyPass(0), 1400, 1500, 0));
        check("P5", "EV + one-day pass: charging still paid", "120.0", () -> bill(new ElectricCar("TN42P5"), UserType.VISITOR, new OneDayPass(0), 0, 130, 10));
        check("P6", "Delivery van + one-day pass", "0.0", () -> bill(new DeliveryVan("TN42P6"), UserType.VISITOR, new OneDayPass(0), 600, 720, 0));
        int[] floors = {50, 80, 60, 100, 40};
        check("F1", "5 floors (50,80,60,100,40) = 330 slots", "330 filled, 331st rejected", () -> {
            ParkingFacility p = new ParkingFacility(floors);
            for (int i = 0; i < 330; i++) p.enter(new Car("TN" + String.format("%05d", i)), UserType.VISITOR, false, 0);
            int filled = 330 - p.freeSlots();
            try { p.enter(new Car("TN99999"), UserType.VISITOR, false, 0); return filled + " filled, 331st accepted"; }
            catch (IllegalStateException e) { return filled + " filled, 331st rejected"; } });
        check("F2", "51st vehicle goes to floor 1, slot 0", "[1, 0]", () -> {
            ParkingFacility p = new ParkingFacility(floors); ParkingTicket t = null;
            for (int i = 0; i < 51; i++) t = p.enter(new Car("TN" + String.format("%05d", i)), UserType.VISITOR, false, 0);
            return "[" + t.getFloor() + ", " + t.getSlot() + "]"; });
        check("F3", "Factory builds VAN and EBIKE", "DeliveryVan EBike", () ->
            VehicleFactory.create("van", "TN43F1").getClass().getSimpleName() + " " + VehicleFactory.create("EBIKE", "TN43F2").getClass().getSimpleName());
        check("F4", "Factory still rejects BUS", "IllegalArgumentException: unknown vehicle type: BUS", () -> VehicleFactory.create("BUS", "TN43F3").toString());
        System.out.println("-".repeat(130));
        System.out.println("Passed " + pass + " of " + total + " tests");
    }
}
