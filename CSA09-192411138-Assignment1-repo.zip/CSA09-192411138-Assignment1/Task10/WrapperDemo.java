/** Task 10: wrapper classes, autoboxing pitfalls and validating setters. */
public class WrapperDemo {
    static class Slot {
        private int number;
        public void setNumber(int n, int max) {
            if (n < 0 || n >= max) throw new IllegalArgumentException("invalid slot number " + n);
            number = n;
        }
        public int getNumber() { return number; }
    }
    public static void main(String[] args) {
        Integer a = 127, b = 127, c = 1000, d = 1000;          // autoboxing
        System.out.println("127 == 127   : " + (a == b) + "   (cached Integer objects)");
        System.out.println("1000 == 1000 : " + (c == d) + "  (two different objects!)");
        System.out.println("1000 equals  : " + c.equals(d));
        Slot s = new Slot();
        try { s.setNumber(7, 5); } catch (IllegalArgumentException e) { System.out.println("Setter rejected: " + e.getMessage()); }
        s.setNumber(3, 5);
        System.out.println("Valid slot stored: " + s.getNumber());
        int parsed = Integer.parseInt("42"); Integer boxed = Integer.valueOf(parsed); int unboxed = boxed;
        System.out.println("parseInt/valueOf/unboxing: " + parsed + " " + boxed + " " + unboxed);
        Integer nothing = null;
        try { int x = nothing; } catch (NullPointerException e) { System.out.println("Unboxing null -> NullPointerException"); }
    }
}
