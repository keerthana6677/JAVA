# CSA09 Assignment 1 - Campus Smart-Parking System

- **Name:** K Keerthana
- **Register number:** 192411138
- **Java version:** OpenJDK 21.0.12 (Java 16 or later is required)
- **Report:** CSA09-192411138-Assignment1-Report.docx

## How to compile and run
Single-file programs (run from the repository root):

    javac -d out/Task08 Task08/FeeDemo.java && java -cp out/Task08 FeeDemo
    java Task01/ArrayVsObjects.java      # also Task02/CastDemo, Task03/ParkingFacility, Task03/FreeStackBench,
                                         # Task04/ConstructorDemo, Task05/StaticDemo, Task06/CtorTrace,
                                         # Task08/DispatchBench, Task10/WrapperDemo

Packaged system (Task 11 and Task 12):

    cd Task11
    javac -d out $(find src -name "*.java")
    java -cp out parking.app.Scenario
    java -cp out parking.app.TestSuite
    java -cp out parking.app.LookupBench
    cd ../Task12
    javac -d out $(find src -name "*.java")
    java -cp out parking.app.Task12Tests
    java -cp out parking.app.TestSuite       # Task 11 tests, unchanged, on the new code

## Results
| Task | Folder | Result |
|---|---|---|
| 1 | Task01 | Parallel arrays and objects: both O(n) search, measured times within noise |
| 2 | Task02 | Integer division gives Rs 60 instead of Rs 90 for 130 min; (minutes+59)/60 gives Rs 90 |
| 3 | Task03 | ParkingFacility output identical to the expected output; stack allocation about 7 ns vs scan up to 188 ns |
| 4 | Task04 | Chaining, copy constructor, static factory; setter style shows an invalid intermediate state |
| 5 | Task05 | Instance counter duplicates ticket 1001; static counter gives 1001, 1002 |
| 6 | Task06 | Constructor order Vehicle, Car, ElectricCar; UML in uml_vehicle.png |
| 7 | Task07 -> Task11/src | Overriding, final, equals/hashCode/toString |
| 8 | Task08 | FeeDemo output identical to expected (30, 90, 210, true) |
| 9 | Task09 -> Task11/src | Abstract class Vehicle, interface Chargeable |
| 10 | Task10 | Integer cache pitfall and validating setter demonstrated |
| 11 | Task11 | 24 of 24 tests pass; scenario total Rs 570 equals hand calculation; HashMap lookup about 15 ns vs array 1 ms at n = 100,000 |
| 12 | Task12 | MODIFY: 3 of 10 classes changed, 7 added; 19 of 19 new tests and 24 of 24 regression tests pass |
