/** Task 5: static vs instance ticket counter with two facilities. */
public class StaticDemo {
    static class BadFacility {            // counter as INSTANCE variable
        private long counter = 1000;
        long issue() { return ++counter; }
    }
    static class GoodFacility {           // counter as STATIC variable
        private static long counter = 1000;
        private final String name;
        GoodFacility(String n) { name = n; }
        static synchronized long issue() { return ++counter; }
    }
    public static void main(String[] args) {
        BadFacility north = new BadFacility(), south = new BadFacility();
        System.out.println("Instance counter: north=" + north.issue() + " south=" + south.issue() + "  <- DUPLICATE ticket number");
        GoodFacility n = new GoodFacility("north"), s = new GoodFacility("south");
        System.out.println("Static counter  : north=" + GoodFacility.issue() + " south=" + GoodFacility.issue() + "  <- unique");
        System.out.println("A ticket reference set to null becomes eligible for garbage collection.");
    }
}
