Task 9 (abstract class Vehicle, interface Chargeable with default and static methods) is implemented in Task11/src/parking/model. See the report, Task 9.
