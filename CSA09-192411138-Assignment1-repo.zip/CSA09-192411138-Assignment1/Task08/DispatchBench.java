/** Task 8 alternative: dynamic dispatch vs instanceof chain (measured). */
public class DispatchBench {
    static abstract class V { abstract double rate(); double fee(int m) { return ((m + 59) / 60) * rate(); } }
    static class TW extends V { double rate() { return 10; } }
    static class Car extends V { double rate() { return 30; } }
    static class EV extends Car { double rate() { return 30; } }
    static class Van extends V { double rate() { return 60; } }
    static class Bike extends V { double rate() { return 5; } }

    static double viaInstanceof(V v, int m) {
        double r;
        if (v instanceof TW) r = 10; else if (v instanceof EV) r = 30; else if (v instanceof Car) r = 30;
        else if (v instanceof Van) r = 60; else if (v instanceof Bike) r = 5; else throw new IllegalStateException();
        return ((m + 59) / 60) * r;
    }
    public static void main(String[] args) {
        V[] vs = { new TW(), new Car(), new EV(), new Van(), new Bike() };
        int N = 50_000_000; double sink = 0;
        for (int i = 0; i < N / 5; i++) { sink += vs[i % 5].fee(130); sink += viaInstanceof(vs[i % 5], 130); }
        long t0 = System.nanoTime();
        for (int i = 0; i < N; i++) sink += vs[i % 5].fee(130);
        long t1 = System.nanoTime();
        for (int i = 0; i < N; i++) sink += viaInstanceof(vs[i % 5], 130);
        long t2 = System.nanoTime();
        System.out.printf("dynamic dispatch : %.2f ns per fee call%n", (t1 - t0) / (double) N);
        System.out.printf("instanceof chain : %.2f ns per fee call (k = 5 types)%n", (t2 - t1) / (double) N);
        if (sink < 0) System.out.println();
    }
}
