/** Task 2: integer division and casting risks in fee calculation. */
public class CastDemo {
    public static void main(String[] args) {
        int minutes = 130; double rate = 30;
        System.out.println("Parking minutes      : " + minutes + ", rate Rs " + rate + "/hour");
        System.out.println("Wrong 1 (int divide) : Rs " + (minutes / 60) * rate);
        System.out.println("Wrong 2 (Math.ceil on int division) : Rs " + Math.ceil(minutes / 60) * rate);
        System.out.println("Wrong 3 (cast too late) : Rs " + (double) (minutes / 60) * rate);
        System.out.println("Right 1 (double division + ceil) : Rs " + Math.ceil(minutes / 60.0) * rate);
        System.out.println("Right 2 (integer ceiling, used)  : Rs " + ((minutes + 59) / 60) * rate);
        int boundary = 60;
        System.out.println("Boundary 60 min -> hours = " + ((boundary + 59) / 60) + " (expected 1)");
        boundary = 61;
        System.out.println("Boundary 61 min -> hours = " + ((boundary + 59) / 60) + " (expected 2)");
        double narrowing = 99.99; int lost = (int) narrowing;
        System.out.println("Narrowing (int) 99.99 = " + lost + "  (fraction truncated, not rounded)");
        long big = 3_000_000_000L; int overflow = (int) big;
        System.out.println("Narrowing (int) 3000000000L = " + overflow + "  (overflow)");
    }
}
