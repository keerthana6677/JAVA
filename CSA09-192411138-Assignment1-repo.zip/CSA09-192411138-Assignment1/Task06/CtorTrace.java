/** Task 6: constructor execution order for ElectricCar. */
public class CtorTrace {
    static class Vehicle {
        Vehicle(String reg) { System.out.println("1. Vehicle(" + reg + ") - superclass constructor runs first"); }
    }
    static class Car extends Vehicle {
        Car(String reg) { super(reg); System.out.println("2. Car(" + reg + ") - sets rate 30"); }
    }
    static class ElectricCar extends Car {
        ElectricCar(String reg) { super(reg); System.out.println("3. ElectricCar(" + reg + ") - adds charging ability"); }
    }
    public static void main(String[] args) {
        System.out.println("new ElectricCar(\"TN03C3\") :");
        new ElectricCar("TN03C3");
    }
}
