package parking.app;

import parking.model.*;
import parking.service.ParkingFacility;

/** Task 11: one-day scenario whose collection is calculated by hand (Rs 570). */
public class Scenario {
    public static void main(String[] args) {
        ParkingFacility p = new ParkingFacility(new int[]{3, 4});
        Object[][] day = {
            // type, reg, user, pass, entry, exit, kWh
            {"TWOWHEELER", "TN01A1", UserType.STUDENT, true,  540, 630, 0},   // 90 min, pass      -> 0
            {"CAR",        "TN02B2", UserType.VISITOR, false, 540, 670, 0},   // 130 min -> 3h     -> 90
            {"EV",         "TN03C3", UserType.VISITOR, false, 540, 670, 10},  // 130 min + 10 kWh  -> 90+120
            {"CAR",        "TN04D4", UserType.STAFF,   true,  540, 1140, 0},  // 600 min, pass     -> 0
            {"CAR",        "TN05E5", UserType.VISITOR, false, 540, 1140, 0},  // 600 min -> cap    -> 240
            {"TWOWHEELER", "TN06F6", UserType.VISITOR, false, 540, 600, 0},   // 60 min boundary   -> 10
            {"TWOWHEELER", "TN07G7", UserType.VISITOR, false, 540, 601, 0},   // 61 min            -> 20
        };
        System.out.println("Facility: 2 floors (3 and 4 slots) = 7 slots");
        for (Object[] d : day) {
            Vehicle v = VehicleFactory.create((String) d[0], (String) d[1]);
            ParkingTicket t = p.enter(v, (UserType) d[2], (Boolean) d[3], (Integer) d[4]);
            System.out.println("ENTER " + t);
        }
        System.out.println("Free slots after all entries: " + p.freeSlots());
        for (Object[] d : day) {
            Bill b = p.exit((String) d[1], (Integer) d[5], (Integer) d[6]);
            System.out.println("EXIT  " + b);
        }
        System.out.println("Free slots after all exits  : " + p.freeSlots());
        System.out.printf("Program total collection    : Rs %.1f%n", p.getTotalCollected());
        System.out.println("Hand-calculated total       : Rs 570.0  (0+90+210+0+240+10+20)");
        System.out.println(p.getTotalCollected() == 570.0 ? "RESULT: MATCH" : "RESULT: MISMATCH");
    }
}
