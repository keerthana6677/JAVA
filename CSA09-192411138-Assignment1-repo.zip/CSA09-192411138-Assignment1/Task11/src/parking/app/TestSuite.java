package parking.app;

import parking.model.*;
import parking.service.ParkingFacility;
import java.util.function.Supplier;

/** Task 11: test table with expected and actual results. */
public class TestSuite {
    static int pass = 0, total = 0;

    static void check(String id, String what, String expected, Supplier<String> actual) {
        String got;
        try { got = actual.get(); } catch (RuntimeException e) { got = e.getClass().getSimpleName() + ": " + e.getMessage(); }
        boolean ok = expected.equals(got);
        total++; if (ok) pass++;
        System.out.printf("%-4s %-38s | %-34s | %-34s | %s%n", id, what, expected, got, ok ? "PASS" : "FAIL");
    }

    static String f(double d) { return String.format("%.1f", d); }

    public static void main(String[] args) {
        System.out.printf("%-4s %-38s | %-34s | %-34s | %s%n", "ID", "Test", "Expected", "Actual", "Result");
        System.out.println("-".repeat(125));
        // ---- normal
        check("N1", "TwoWheeler 130 min", "30.0", () -> f(new TwoWheeler("TN01A1").calculateFee(130)));
        check("N2", "Car 130 min", "90.0", () -> f(new Car("TN02B2").calculateFee(130)));
        check("N3", "EV 130 min + 10 kWh", "210.0", () -> { ElectricCar e = new ElectricCar("TN03C3"); return f(e.calculateFee(130) + e.chargingFee(10)); });
        check("N4", "Student with monthly pass parks free", "0.0", () -> {
            ParkingFacility p = new ParkingFacility(new int[]{2});
            p.enter(new Car("TN10A1"), UserType.STUDENT, true, 0); return f(p.exit("TN10A1", 500, 0).total()); });
        check("N5", "Visitor with 'pass' still pays", "90.0", () -> {
            ParkingFacility p = new ParkingFacility(new int[]{2});
            p.enter(new Car("TN11A1"), UserType.VISITOR, true, 0); return f(p.exit("TN11A1", 130, 0).total()); });
        check("N6", "Ticket numbers strictly increase", "true", () -> {
            ParkingFacility p = new ParkingFacility(new int[]{2});
            long a = p.enter(new Car("TN12A1"), UserType.VISITOR, false, 0).getTicketNo(); p.exit("TN12A1", 10, 0);
            long b = p.enter(new Car("TN12A1"), UserType.VISITOR, false, 0).getTicketNo(); return String.valueOf(b > a); });
        // ---- boundary
        check("B1", "Zero-minute parking", "0.0", () -> f(new Car("TN20A1").calculateFee(0)));
        check("B2", "Exactly 60 min (slab boundary)", "30.0", () -> f(new Car("TN20A1").calculateFee(60)));
        check("B3", "61 min (just over boundary)", "60.0", () -> f(new Car("TN20A1").calculateFee(61)));
        check("B4", "480 min = daily cap reached", "240.0", () -> f(new Car("TN20A1").calculateFee(480)));
        check("B5", "600 min capped at daily max", "240.0", () -> f(new Car("TN20A1").calculateFee(600)));
        check("B6", "1440 min = exactly one day", "240.0", () -> f(new Car("TN20A1").calculateFee(1440)));
        check("B7", "1441 min = day + 1 started hour", "270.0", () -> f(new Car("TN20A1").calculateFee(1441)));
        check("B8", "Last free slot is used, then full", "[0, 1] then facility full", () -> {
            ParkingFacility p = new ParkingFacility(new int[]{2});
            p.enter(new Car("TN21A1"), UserType.VISITOR, false, 0);
            ParkingTicket t = p.enter(new Car("TN21A2"), UserType.VISITOR, false, 0);
            String first = "[" + t.getFloor() + ", " + t.getSlot() + "]";
            try { p.enter(new Car("TN21A3"), UserType.VISITOR, false, 0); return first + " but accepted"; }
            catch (IllegalStateException e) { return first + " then " + e.getMessage(); } });
        check("B9", "Slot reused after exit", "[0, 0]", () -> {
            ParkingFacility p = new ParkingFacility(new int[]{1});
            p.enter(new Car("TN22A1"), UserType.VISITOR, false, 0); p.exit("TN22A1", 5, 0);
            ParkingTicket t = p.enter(new Car("TN22A2"), UserType.VISITOR, false, 0);
            return "[" + t.getFloor() + ", " + t.getSlot() + "]"; });
        // ---- invalid
        check("I1", "Unknown vehicle type BUS", "IllegalArgumentException: unknown vehicle type: BUS", () -> VehicleFactory.create("BUS", "TN30A1").toString());
        check("I2", "Duplicate registration number", "IllegalArgumentException: duplicate registration: TN31A1", () -> {
            ParkingFacility p = new ParkingFacility(new int[]{3});
            p.enter(new Car("TN31A1"), UserType.VISITOR, false, 0);
            return p.enter(new ElectricCar("TN31A1"), UserType.VISITOR, false, 5).toString(); });
        check("I3", "Invalid slot number release(0, 99)", "false", () -> String.valueOf(new ParkingFacility(new int[]{2}).release(0, 99)));
        check("I4", "Invalid floor number release(-1, 0)", "false", () -> String.valueOf(new ParkingFacility(new int[]{2}).release(-1, 0)));
        check("I5", "Negative duration", "IllegalArgumentException: duration cannot be negative: -5", () -> f(new Car("TN32A1").calculateFee(-5)));
        check("I6", "Exit of unknown vehicle", "IllegalArgumentException: no active ticket for TN99Z9", () -> f(new ParkingFacility(new int[]{1}).exit("TN99Z9", 10, 0).total()));
        check("I7", "Charging a non-EV car", "IllegalArgumentException: TN33A1 cannot be charged", () -> {
            ParkingFacility p = new ParkingFacility(new int[]{1});
            p.enter(new Car("TN33A1"), UserType.VISITOR, false, 0); return f(p.exit("TN33A1", 60, 5).total()); });
        check("I8", "Invalid registration 'a b'", "IllegalArgumentException: invalid registration number: a b", () -> new Car("a b").toString());
        check("I9", "equals(): Car vs ElectricCar, same reg", "true", () -> String.valueOf(new Car("TN34A1").equals(new ElectricCar("TN34A1"))));
        System.out.println("-".repeat(125));
        System.out.println("Passed " + pass + " of " + total + " tests");
    }
}
