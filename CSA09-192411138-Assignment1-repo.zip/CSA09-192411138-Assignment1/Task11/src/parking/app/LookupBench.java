package parking.app;

import parking.model.*;
import java.util.*;

/** Task 11 alternative: find a ticket on exit in array / ArrayList / HashMap (measured). */
public class LookupBench {
    public static void main(String[] args) {
        System.out.printf("%-8s %-16s %-16s %-16s %-30s%n", "n", "array (ns)", "ArrayList (ns)", "HashMap (ns)", "extra heap KB (list / map)");
        for (int n : new int[]{1_000, 10_000, 100_000}) {
            ParkingTicket[] tickets = new ParkingTicket[n];
            for (int i = 0; i < n; i++)
                tickets[i] = new ParkingTicket(new Car("TN" + String.format("%06d", i)), UserType.VISITOR, 0, i, 0);
            String target = "TN" + String.format("%06d", n - 1);

            long m0 = used(); ParkingTicket[] arr = tickets.clone(); long m1 = used();
            List<ParkingTicket> list = new ArrayList<>(Arrays.asList(tickets)); long m2 = used();
            Map<String, ParkingTicket> map = new HashMap<>();
            for (ParkingTicket t : tickets) map.put(t.getVehicle().getRegNo(), t); long m3 = used();

            int reps = Math.max(200, 20_000_000 / n); long sink = 0;
            int mreps = 3_000_000;
            for (int w = 0; w < reps; w++) { sink += fa(arr, target); sink += fl(list, target); }
            for (int w = 0; w < mreps; w++) sink += map.get(target).getSlot();
            long t0 = System.nanoTime(); for (int r = 0; r < reps; r++) sink += fa(arr, target);
            long t1 = System.nanoTime(); for (int r = 0; r < reps; r++) sink += fl(list, target);
            long t2 = System.nanoTime(); for (int r = 0; r < mreps; r++) sink += map.get(target).getSlot();
            long t3 = System.nanoTime();
            System.out.printf("%-8d %-16d %-16d %-16d %d / %d%n", n, (t1 - t0) / reps, (t2 - t1) / reps, (t3 - t2) / mreps,
                    (m2 - m1) / 1024, (m3 - m2) / 1024);
            if (sink == 7) System.out.println();
        }
    }
    static long used() { System.gc(); System.gc(); Runtime r = Runtime.getRuntime(); return r.totalMemory() - r.freeMemory(); }
    static int fa(ParkingTicket[] a, String reg) { for (int i = 0; i < a.length; i++) if (a[i].getVehicle().getRegNo().equals(reg)) return i; return -1; }
    static int fl(List<ParkingTicket> l, String reg) { for (int i = 0; i < l.size(); i++) if (l.get(i).getVehicle().getRegNo().equals(reg)) return i; return -1; }
}
