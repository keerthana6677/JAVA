package parking.model;

public enum UserType {
    STUDENT(true), STAFF(true), VISITOR(false);
    private final boolean passEligible;
    UserType(boolean passEligible) { this.passEligible = passEligible; }
    public boolean isPassEligible() { return passEligible; }
}
