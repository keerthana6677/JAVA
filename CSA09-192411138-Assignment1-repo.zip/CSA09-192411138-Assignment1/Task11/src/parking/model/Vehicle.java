package parking.model;

/** Abstract superclass: common data and the fee algorithm; subclasses supply the rate. */
public abstract class Vehicle {
    public static final int MINUTES_PER_DAY = 1440;
    protected static final int CAP_HOURS = 8;          // daily maximum = 8 hours' fee

    private final String regNo;

    protected Vehicle(String regNo) {
        if (regNo == null || !regNo.matches("[A-Z0-9]{4,12}"))
            throw new IllegalArgumentException("invalid registration number: " + regNo);
        this.regNo = regNo;
    }

    public final String getRegNo() { return regNo; }

    protected abstract double ratePerHour();

    protected double dailyCap() { return ratePerHour() * CAP_HOURS; }

    /** Compile-time overload 1: fee for a stay of the given length. */
    public double calculateFee(int minutes) {
        if (minutes < 0) throw new IllegalArgumentException("duration cannot be negative: " + minutes);
        if (minutes == 0) return 0;
        int days = minutes / MINUTES_PER_DAY;
        int rem = minutes % MINUTES_PER_DAY;
        int hours = (rem + 59) / 60;                    // integer ceiling: every started hour counts
        double remFee = Math.min(hours * ratePerHour(), dailyCap());
        return days * dailyCap() + remFee;
    }

    /** Compile-time overload 2: fee for a stay between two clock times (minutes since day 0). */
    public double calculateFee(int entryMin, int exitMin) {
        if (exitMin < entryMin) throw new IllegalArgumentException("exit before entry");
        return calculateFee(exitMin - entryMin);
    }

    @Override public boolean equals(Object o) {
        return o instanceof Vehicle && regNo.equals(((Vehicle) o).regNo);
    }
    @Override public int hashCode() { return regNo.hashCode(); }
    @Override public String toString() { return getClass().getSimpleName() + "[" + regNo + "]"; }
}
