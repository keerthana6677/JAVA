package parking.model;

public record Bill(long ticketNo, String regNo, double parkingFee, double chargingFee) {
    public double total() { return parkingFee + chargingFee; }
    @Override public String toString() {
        return String.format("Bill[ticket=%d, %s, parking=%.1f, charging=%.1f, total=%.1f]",
                ticketNo, regNo, parkingFee, chargingFee, total());
    }
}
