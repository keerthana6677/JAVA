package parking.model;

/** Capability: a vehicle that can be charged at an EV charging point. */
public interface Chargeable {
    double RATE_PER_KWH = 12.0;

    double chargingFee(int kWh);

    /** Default method: label printed on the bill. */
    default String chargerLabel() { return "EV charging"; }

    /** Static method: shared validation. */
    static int checkKwh(int kWh) {
        if (kWh < 0) throw new IllegalArgumentException("kWh cannot be negative: " + kWh);
        return kWh;
    }
}
