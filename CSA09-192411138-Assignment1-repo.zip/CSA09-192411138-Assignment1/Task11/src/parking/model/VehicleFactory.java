package parking.model;

/** Creates a vehicle from a type name; rejects unknown types. */
public final class VehicleFactory {
    private VehicleFactory() { }
    public static Vehicle create(String type, String regNo) {
        if (type == null) throw new IllegalArgumentException("vehicle type missing");
        switch (type.trim().toUpperCase()) {
            case "TWOWHEELER": return new TwoWheeler(regNo);
            case "CAR":        return new Car(regNo);
            case "EV":         return new ElectricCar(regNo);
            default: throw new IllegalArgumentException("unknown vehicle type: " + type);
        }
    }
}
