package parking.model;

public class ElectricCar extends Car implements Chargeable {
    public ElectricCar(String regNo) { super(regNo); }
    @Override public double chargingFee(int kWh) { return Chargeable.checkKwh(kWh) * RATE_PER_KWH; }
}
