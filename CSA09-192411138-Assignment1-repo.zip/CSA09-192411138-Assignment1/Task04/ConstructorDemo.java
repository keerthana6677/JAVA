/** Task 4: constructors, this(), copy constructor, setters vs static factory. */
public class ConstructorDemo {
    static class Ticket {
        private static long counter = 1000;
        private final long no; private final String reg; private final int entryMin; private final String type;

        Ticket(String reg, int entryMin) { this(reg, "CAR", entryMin); System.out.println("  Ticket(reg, entry) -> chained"); }
        Ticket(String reg, String type, int entryMin) {
            if (reg == null || reg.isEmpty() || entryMin < 0) throw new IllegalArgumentException("invalid ticket data");
            this.no = ++counter; this.reg = reg; this.type = type; this.entryMin = entryMin;
            System.out.println("  Ticket(reg, type, entry) -> #" + no);
        }
        Ticket(Ticket o) { this.no = o.no; this.reg = o.reg; this.type = o.type; this.entryMin = o.entryMin;
            System.out.println("  copy constructor -> duplicate of #" + no + " (counter unchanged)"); }
        static Ticket forEv(String reg, int entry) { return new Ticket(reg, "EV", entry); }
        public String toString() { return "Ticket#" + no + "[" + reg + "," + type + "," + entryMin + "]"; }
    }
    /** Alternative: default constructor + setters leaves an invalid object in between. */
    static class LooseTicket {
        String reg; int entryMin;
        void setReg(String r) { reg = r; } void setEntry(int e) { entryMin = e; }
    }

    public static void main(String[] args) {
        System.out.println("Parameterised (chained):"); Ticket t1 = new Ticket("TN01A1", 540);
        System.out.println("Overloaded (full):"); Ticket t2 = new Ticket("TN02B2", "EV", 600);
        System.out.println("Copy constructor:"); Ticket dup = new Ticket(t1);
        System.out.println("Static factory:"); Ticket t3 = Ticket.forEv("TN03C3", 700);
        System.out.println(t1 + "  " + t2 + "  " + dup + "  " + t3);
        System.out.println("t1 == dup ? " + (t1 == dup) + "   (different objects on the heap, same ticket number)");
        LooseTicket lt = new LooseTicket();
        System.out.println("Setter style, before setters run: reg=" + lt.reg + ", entry=" + lt.entryMin + "  <- invalid state is visible");
        try { new Ticket("", 10); } catch (IllegalArgumentException e) { System.out.println("Constructor rejects bad data: " + e.getMessage()); }
    }
}
