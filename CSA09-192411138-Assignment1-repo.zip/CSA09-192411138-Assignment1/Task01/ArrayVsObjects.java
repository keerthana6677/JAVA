import java.util.*;

/** Task 1 alternative concept: parallel String arrays vs Vehicle objects. */
public class ArrayVsObjects {
    static class Vehicle {
        final String regNo, type; final String entryTime;
        Vehicle(String r, String t, String e) { regNo = r; type = t; entryTime = e; }
    }
    public static void main(String[] args) {
        int[] sizes = {1_000, 10_000, 100_000};
        System.out.printf("%-10s %-22s %-22s%n", "n", "parallel arrays (ns)", "Vehicle objects (ns)");
        for (int n : sizes) {
            String[] regNo = new String[n], type = new String[n], entry = new String[n];
            List<Vehicle> list = new ArrayList<>();
            for (int i = 0; i < n; i++) {
                regNo[i] = "TN" + String.format("%06d", i); type[i] = "CAR"; entry[i] = "09:00";
                list.add(new Vehicle(regNo[i], type[i], entry[i]));
            }
            String target = regNo[n - 1];            // worst case: last element
            int reps = 20_000_000 / n;
            long sink = 0;
            for (int w = 0; w < reps; w++) { sink += findArr(regNo, target); sink += findObj(list, target); } // warm-up
            long t0 = System.nanoTime();
            for (int r = 0; r < reps; r++) sink += findArr(regNo, target);
            long t1 = System.nanoTime();
            for (int r = 0; r < reps; r++) sink += findObj(list, target);
            long t2 = System.nanoTime();
            System.out.printf("%-10d %-22d %-22d%n", n, (t1 - t0) / reps, (t2 - t1) / reps);
            if (sink == 42) System.out.println();
        }
    }
    static int findArr(String[] regNo, String t) {
        for (int i = 0; i < regNo.length; i++) if (regNo[i].equals(t)) return i;
        return -1;
    }
    static int findObj(List<Vehicle> l, String t) {
        for (int i = 0; i < l.size(); i++) if (l.get(i).regNo.equals(t)) return i;
        return -1;
    }
}
