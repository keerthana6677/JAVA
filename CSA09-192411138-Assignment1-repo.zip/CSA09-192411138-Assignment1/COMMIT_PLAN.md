# Commit plan (run these as you finish each task, so the history shows progress)
git init && git branch -M main
git remote add origin https://github.com/<your-username>/CSA09-192411138-Assignment1.git
git add Task01 && git commit -m "Task 1: parallel arrays vs objects measurement"
git add Task02 && git commit -m "Task 2: casting and integer division demo"
git add Task03 && git commit -m "Task 3: ParkingFacility complete the code and stack benchmark"
git add Task04 && git commit -m "Task 4: constructors, copy constructor, static factory"
git add Task05 && git commit -m "Task 5: static counter demo"
git add Task06 && git commit -m "Task 6: inheritance trace and UML"
git add Task11 Task07 Task09 && git commit -m "Tasks 7, 9, 11: full parking system, tests and scenario"
git add Task08 && git commit -m "Task 8: FeeDemo complete the code and dispatch benchmark"
git add Task10 && git commit -m "Task 10: wrapper and validation demo"
git add Task12 && git commit -m "Task 12: e-bike, van, passes, 5 uneven floors"
git add README.md COMMIT_PLAN.md && git commit -m "README"
git push -u origin main
