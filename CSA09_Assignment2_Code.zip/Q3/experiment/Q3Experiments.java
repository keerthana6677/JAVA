import java.util.*;

public class Q3Experiments {
    // Junior developer's class: equals on regNo, hashCode NOT overridden
    static class BadStudent {
        final String regNo, name;
        BadStudent(String r, String n) { regNo = r; name = n; }
        @Override public boolean equals(Object o) { return o instanceof BadStudent b && regNo.equals(b.regNo); }
        @Override public String toString() { return regNo + " " + name; }
    }
    // Corrected class: hashCode uses exactly the field used by equals
    static class GoodStudent {
        final String regNo, name;
        GoodStudent(String r, String n) { regNo = r; name = n; }
        @Override public boolean equals(Object o) { return o instanceof GoodStudent g && regNo.equals(g.regNo); }
        @Override public int hashCode() { return Objects.hash(regNo); }
        @Override public String toString() { return regNo + " " + name; }
    }
    // Mutable key: regNo is NOT final and takes part in hashCode
    static class MutableStudent {
        String regNo; final String name;
        MutableStudent(String r, String n) { regNo = r; name = n; }
        @Override public boolean equals(Object o) { return o instanceof MutableStudent m && regNo.equals(m.regNo); }
        @Override public int hashCode() { return Objects.hash(regNo); }
        @Override public String toString() { return regNo + " " + name; }
    }
    // Comparable that is inconsistent with equals (compares name only)
    static class NameOrdered implements Comparable<NameOrdered> {
        final String regNo, name;
        NameOrdered(String r, String n) { regNo = r; name = n; }
        @Override public boolean equals(Object o) { return o instanceof NameOrdered x && regNo.equals(x.regNo); }
        @Override public int hashCode() { return regNo.hashCode(); }
        @Override public int compareTo(NameOrdered o) { return name.compareTo(o.name); }
        @Override public String toString() { return regNo + " " + name; }
    }

    public static void main(String[] a) {
        System.out.println("=== TEST 1: HashSet appears to work (same object scanned twice) ===");
        Set<BadStudent> s1 = new HashSet<>();
        BadStudent arun = new BadStudent("192311001", "Arun");
        s1.add(arun); s1.add(new BadStudent("192311002", "Divya")); s1.add(arun);
        System.out.println("Prediction: 2 (same reference => same identity hash, equals true)");
        System.out.println("Observed  : " + s1.size());

        System.out.println("\n=== TEST 2: duplicates exposed (two different objects, same regNo) ===");
        BadStudent x = new BadStudent("192311001", "Arun"), y = new BadStudent("192311001", "Arun");
        Set<BadStudent> s2 = new HashSet<>(List.of(x));
        s2.add(y);
        s2.add(new BadStudent("192311002", "Divya"));
        System.out.println("x.equals(y) = " + x.equals(y) + ", x.hashCode()==y.hashCode() : " + (x.hashCode() == y.hashCode()));
        System.out.println("Prediction: 3 (equal objects land in different buckets, equals() never consulted)");
        System.out.println("Observed  : " + s2.size() + "  " + s2.stream().map(Object::toString).sorted().toList());
        System.out.println("contains(new BadStudent(\"192311001\",..)) = " + s2.contains(new BadStudent("192311001", "Arun")));

        System.out.println("\n=== TEST 2b: same scans with corrected class ===");
        Set<GoodStudent> g = new HashSet<>();
        g.add(new GoodStudent("192311001", "Arun")); g.add(new GoodStudent("192311002", "Divya")); g.add(new GoodStudent("192311001", "Arun"));
        System.out.println("Prediction: 2   Observed: " + g.size() + "   contains(192311001) = " + g.contains(new GoodStudent("192311001", "x")));

        System.out.println("\n=== TEST 3: mutate regNo AFTER insertion (hashCode uses regNo) ===");
        MutableStudent m = new MutableStudent("192311001", "Arun");
        Set<MutableStudent> s3 = new HashSet<>(); s3.add(m);
        m.regNo = "192311999";
        System.out.println("Prediction: size 1, but contains(m) = false and re-adding m gives size 2 (stored in the old bucket)");
        System.out.println("Observed  : size=" + s3.size() + ", contains(m)=" + s3.contains(m) + ", iterating finds it: " + s3.iterator().next());
        s3.add(m);
        System.out.println("After s3.add(m): size=" + s3.size() + "  (same object now present twice)");

        System.out.println("\n=== TEST 4: TreeSet whose compareTo (name) is inconsistent with equals (regNo) ===");
        Set<NameOrdered> ts = new TreeSet<>();
        ts.add(new NameOrdered("192311001", "Arun")); ts.add(new NameOrdered("192311050", "Arun")); ts.add(new NameOrdered("192311002", "Divya"));
        System.out.println("Two different students (different regNo) both named Arun.");
        System.out.println("Prediction: TreeSet size 2 (second Arun treated as duplicate because compareTo == 0); HashSet size 3");
        System.out.println("Observed  : TreeSet size=" + ts.size() + " " + ts + "   HashSet size=" +
            new HashSet<>(List.of(new NameOrdered("192311001", "Arun"), new NameOrdered("192311050", "Arun"), new NameOrdered("192311002", "Divya"))).size());

        System.out.println("\n=== Alternatives for de-duplication ===");
        Map<String, GoodStudent> byReg = new HashMap<>();
        TreeSet<GoodStudent> byTree = new TreeSet<>(Comparator.comparing(st -> st.regNo));
        for (String r : new String[]{"192311001", "192311002", "192311001"}) {
            byReg.putIfAbsent(r, new GoodStudent(r, "n")); byTree.add(new GoodStudent(r, "n"));
        }
        System.out.println("HashMap<String,Student> unique = " + byReg.size() + "   TreeSet(Comparator on regNo) unique = " + byTree.size());
    }
}
