import java.lang.management.ManagementFactory;
import java.util.*;

public class Q2 {
    static long sink;
    static final com.sun.management.ThreadMXBean TB = (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();
    @SuppressWarnings("deprecation") static long alloc() { return TB.getThreadAllocatedBytes(Thread.currentThread().getId()); }
    static class Song { final int id; Song(int i) { id = i; } }
    static final Song S = new Song(1);

    static double ms(Runnable r) { // best-of-3 after one warm-up, in ms
        r.run();
        double best = 1e18;
        for (int i = 0; i < 3; i++) { long t = System.nanoTime(); r.run(); best = Math.min(best, (System.nanoTime() - t) / 1e6); }
        return best;
    }
    static List<Song> filled(List<Song> l, int n) { for (int i = 0; i < n; i++) l.add(S); return l; }

    public static void main(String[] args) {
        int OPS = 1000;
        Random rnd = new Random(7);
        System.out.println("Java " + System.getProperty("java.version") + "   (times in ms, best of 3; " + OPS + " ops for insert/remove/get)");
        System.out.printf("%-34s %10s %10s %10s%n", "Operation", "n=10,000", "n=50,000", "n=200,000");
        int[] sizes = {10_000, 50_000, 200_000};
        String[] names = {"ArrayList", "LinkedList", "ArrayDeque"};
        Map<String, double[]> res = new LinkedHashMap<>();
        for (int s = 0; s < 3; s++) {
            int n = sizes[s];
            int[] ks = new int[OPS]; for (int i = 0; i < OPS; i++) ks[i] = rnd.nextInt(n);
            for (String nm : names) {
                boolean dq = nm.equals("ArrayDeque");
                java.util.function.Supplier<Collection<Song>> mk = () -> dq ? new ArrayDeque<Song>() : (nm.equals("ArrayList") ? new ArrayList<Song>() : new LinkedList<Song>());
                put(res, nm + " add at end (n adds)", s, ms(() -> { Collection<Song> c = mk.get(); for (int i = 0; i < n; i++) c.add(S); sink += c.size(); }));
                if (dq) {
                    ArrayDeque<Song> d = new ArrayDeque<>(); for (int i = 0; i < n; i++) d.add(S);
                    put(res, nm + " insert at front", s, ms(() -> { for (int i = 0; i < OPS; i++) d.addFirst(S); }));
                    put(res, nm + " remove at front", s, ms(() -> { for (int i = 0; i < OPS; i++) d.pollFirst(); }));
                    put(res, nm + " iterate all", s, ms(() -> { int c = 0; for (Song x : d) c += x.id; sink += c; }));
                } else {
                    List<Song> l = (List<Song>) filled((List<Song>) mk.get(), n);
                    put(res, nm + " insert at front", s, ms(() -> { for (int i = 0; i < OPS; i++) l.add(0, S); }));
                    put(res, nm + " remove at front", s, ms(() -> { for (int i = 0; i < OPS; i++) l.remove(0); }));
                    put(res, nm + " insert in middle", s, ms(() -> { for (int i = 0; i < OPS; i++) l.add(l.size() / 2, S); }));
                    put(res, nm + " remove in middle", s, ms(() -> { for (int i = 0; i < OPS; i++) l.remove(l.size() / 2); }));
                    put(res, nm + " get k-th (random k)", s, ms(() -> { int c = 0; for (int k : ks) c += l.get(k).id; sink += c; }));
                    put(res, nm + " iterate all", s, ms(() -> { int c = 0; for (Song x : l) c += x.id; sink += c; }));
                }
            }
            // plain array with manual shifting
            Song[] arr = new Song[n + 2 * OPS + 10]; Arrays.fill(arr, 0, n, S);
            int[] size = {n};
            put(res, "Plain array insert at front (manual loop)", s, ms(() -> { size[0] = n;
                for (int i = 0; i < OPS; i++) { for (int j = size[0]; j > 0; j--) arr[j] = arr[j - 1]; arr[0] = S; size[0]++; } }));
            put(res, "Plain array insert middle (manual loop)", s, ms(() -> { size[0] = n;
                for (int i = 0; i < OPS; i++) { int p = size[0] / 2; for (int j = size[0]; j > p; j--) arr[j] = arr[j - 1]; arr[p] = S; size[0]++; } }));
            put(res, "Plain array get k-th", s, ms(() -> { int c = 0; for (int k : ks) c += arr[k].id; sink += c; }));
        }
        for (var e : res.entrySet()) System.out.printf("%-42s %10.3f %10.3f %10.3f%n", e.getKey(), e.getValue()[0], e.getValue()[1], e.getValue()[2]);

        // memory per element
        int N = 1_000_000;
        long a0 = alloc(); ArrayList<Song> al = new ArrayList<>(); for (int i = 0; i < N; i++) al.add(S); long aA = alloc() - a0;
        a0 = alloc(); LinkedList<Song> ll = new LinkedList<>(); for (int i = 0; i < N; i++) ll.add(S); long aL = alloc() - a0;
        a0 = alloc(); ArrayDeque<Song> ad = new ArrayDeque<>(); for (int i = 0; i < N; i++) ad.add(S); long aD = alloc() - a0;
        System.out.printf("%nBytes allocated per element while adding 1,000,000 elements (growth garbage included):%n  ArrayList %.1f   LinkedList %.1f   ArrayDeque %.1f%n", aA / (double) N, aL / (double) N, aD / (double) N);

        // Up Next queue: songs added at both ends, removed from the front
        System.out.println("\n== 'Up Next' queue: 50,000 songs, then 50,000 x (addLast, addFirst, removeFirst) ==");
        int Q = 50_000;
        double t1 = ms(() -> { List<Song> l = filled(new ArrayList<>(), Q); for (int i = 0; i < Q; i++) { l.add(S); l.add(0, S); l.remove(0); } sink += l.size(); });
        double t2 = ms(() -> { LinkedList<Song> l = (LinkedList<Song>) filled(new LinkedList<>(), Q); for (int i = 0; i < Q; i++) { l.addLast(S); l.addFirst(S); l.removeFirst(); } sink += l.size(); });
        double t3 = ms(() -> { ArrayDeque<Song> d = new ArrayDeque<>(); for (int i = 0; i < Q; i++) d.add(S); for (int i = 0; i < Q; i++) { d.addLast(S); d.addFirst(S); d.pollFirst(); } sink += d.size(); });
        System.out.printf("ArrayList %.2f ms | LinkedList %.2f ms | ArrayDeque %.2f ms%n", t1, t2, t3);
        System.out.println("(checksum " + sink + ")");
    }
    static void put(Map<String, double[]> m, String k, int i, double v) { m.computeIfAbsent(k, x -> new double[3])[i] = v; }
}
