import java.util.*;

public class Q6Study {
    record Patient(String name, int severity, long arrival) { public String toString() { return name + "(S" + severity + ")"; } }
    static final Comparator<Patient> RULE = Comparator.comparingInt(Patient::severity).thenComparingLong(Patient::arrival);
    static long sink;
    static double ms(Runnable r) { r.run(); double b = 1e18; for (int i = 0; i < 3; i++) { long t = System.nanoTime(); r.run(); b = Math.min(b, (System.nanoTime() - t) / 1e6); } return b; }

    public static void main(String[] args) {
        System.out.println("Java " + System.getProperty("java.version"));
        // ---- hand-verified instance (8 patients)
        String[] nm = {"Asha", "Dev", "Ravi", "John", "Isha", "Lata", "Meena", "Kumar"};
        int[] sv = {5, 4, 3, 3, 2, 2, 1, 1};
        PriorityQueue<Patient> pq = new PriorityQueue<>(RULE); Queue<Patient> fifo = new ArrayDeque<>();
        for (int i = 0; i < 8; i++) { Patient p = new Patient(nm[i], sv[i], i); pq.add(p); fifo.add(p); }
        System.out.println("\n=== Correctness check (8 patients, arrival order shown) ===");
        System.out.println("Arrival order        : " + fifo);
        System.out.println("Hand-worked answer   : [Meena(S1), Kumar(S1), Isha(S2), Lata(S2), Ravi(S3), John(S3), Dev(S4), Asha(S5)]");
        System.out.println("printing the PQ      : " + pq + "   <- heap array order, NOT treatment order");
        List<Patient> served = new ArrayList<>(); while (!pq.isEmpty()) served.add(pq.poll());
        System.out.println("poll() until empty   : " + served);
        System.out.println("Matches hand answer  : " + served.toString().equals("[Meena(S1), Kumar(S1), Isha(S2), Lata(S2), Ravi(S3), John(S3), Dev(S4), Asha(S5)]"));
        System.out.println("Plain FIFO would serve: " + fifo + "   <- Asha(S5) first, Meena/Kumar (S1) last: unacceptable");

        // ---- growth
        System.out.println("\n=== Growth: n admits then n serves, ms (best of 3) ===");
        System.out.printf("%-34s %9s %9s %9s %11s%n", "Design", "n=1,000", "n=10,000", "n=50,000", "n=1,000,000");
        int[] ns = {1000, 10_000, 50_000, 1_000_000};
        Random rnd = new Random(5);
        for (String d : new String[]{"PriorityQueue (binary heap)", "5 FIFO queues (array of ArrayDeque)", "Sorted LinkedList (insert in order)"}) {
            StringBuilder row = new StringBuilder(String.format("%-34s", d));
            for (int n : ns) {
                if (d.startsWith("Sorted") && n > 50_000) { row.append(String.format(" %11s", "skipped")); continue; }
                int[] sev = new int[n]; for (int i = 0; i < n; i++) sev[i] = 1 + rnd.nextInt(5);
                double t;
                if (d.startsWith("Priority")) t = ms(() -> { PriorityQueue<Patient> q = new PriorityQueue<>(RULE); for (int i = 0; i < n; i++) q.add(new Patient("p", sev[i], i)); Patient p; while ((p = q.poll()) != null) sink += p.arrival; });
                else if (d.startsWith("5 FIFO")) t = ms(() -> { @SuppressWarnings("unchecked") ArrayDeque<Patient>[] b = new ArrayDeque[6]; for (int i = 1; i <= 5; i++) b[i] = new ArrayDeque<>();
                    for (int i = 0; i < n; i++) b[sev[i]].add(new Patient("p", sev[i], i));
                    for (int s = 1; s <= 5; s++) { Patient p; while ((p = b[s].poll()) != null) sink += p.arrival; } });
                else t = ms(() -> { LinkedList<Patient> l = new LinkedList<>();
                    for (int i = 0; i < n; i++) { Patient np = new Patient("p", sev[i], i); ListIterator<Patient> it = l.listIterator(); while (it.hasNext()) { if (it.next().severity() > np.severity()) { it.previous(); break; } } it.add(np); }
                    while (!l.isEmpty()) sink += l.removeFirst().arrival; });
                row.append(String.format(" %11.2f", t));
            }
            System.out.println(row.toString().replaceAll("  +", "  "));
        }
        // per-operation cost
        System.out.println("\n=== Per-operation cost of PriorityQueue (ns/op, averaged over n adds then n polls) ===");
        for (int n : new int[]{1000, 100_000, 1_000_000}) {
            PriorityQueue<Patient> q = new PriorityQueue<>(RULE); Patient[] ps = new Patient[n]; for (int i = 0; i < n; i++) ps[i] = new Patient("p", 1 + rnd.nextInt(5), i);
            for (int w = 0; w < 2; w++) { q.clear(); for (Patient p : ps) q.add(p); while (q.poll() != null) ; }
            long t0 = System.nanoTime(); for (Patient p : ps) q.add(p); long t1 = System.nanoTime(); while (q.poll() != null) ; long t2 = System.nanoTime();
            System.out.printf("n=%,9d   add %.1f ns/op   poll %.1f ns/op%n", n, (t1 - t0) / (double) n, (t2 - t1) / (double) n);
        }
        System.out.println("A city hospital: 5,000 patients/day -> 5,000 adds + 5,000 polls = about " +
            String.format("%.2f ms", ms(() -> { PriorityQueue<Patient> q = new PriorityQueue<>(RULE); for (int i = 0; i < 5000; i++) q.add(new Patient("p", 1 + (i * 7) % 5, i)); while (q.poll() != null) ; })) + " of queue work for the entire day");

        // ---- starvation and fair rule
        System.out.println("\n=== Starvation: one S5 patient at t=0, then 2 severe (S1/S2) arrivals and 2 services per tick ===");
        for (int K : new int[]{0, 20, 100}) {
            // K = 0 means strict severity; otherwise priority key = arrival + K*severity (static key, still O(log n))
            Comparator<Patient> cmp = K == 0 ? RULE : Comparator.comparingLong((Patient p) -> p.arrival() + (long) K * p.severity()).thenComparingLong(Patient::arrival);
            PriorityQueue<Patient> q = new PriorityQueue<>(cmp); long id = 0;
            q.add(new Patient("Asha", 5, id++)); long servedAt = -1;
            for (int tick = 1; tick <= 1000 && servedAt < 0; tick++) {
                q.add(new Patient("x", 1, tick * 10L)); q.add(new Patient("y", 2, tick * 10L + 1));
                for (int s = 0; s < 2; s++) { Patient p = q.poll(); if (p.name().equals("Asha")) servedAt = tick; }
            }
            System.out.println((K == 0 ? "Strict severity rule      " : "Aging key arrival+" + K + "*sev ") + " -> S5 patient " + (servedAt < 0 ? "STILL WAITING after 1000 ticks" : "served at tick " + servedAt));
        }
        System.out.println("(checksum " + sink + ")");
    }
}
