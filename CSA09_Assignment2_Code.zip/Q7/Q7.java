import java.lang.management.ManagementFactory;
import java.util.concurrent.atomic.AtomicLong;

/** Q7: redesign of the Q1 e-ticket generator. Original = '+' loop + shared StringBuffer log. */
public class Q7 {
    static final com.sun.management.ThreadMXBean TB = (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();
    @SuppressWarnings("deprecation") static long alloc() { return TB.getThreadAllocatedBytes(Thread.currentThread().getId()); }
    static String[] f(int n) { String[] a = new String[n]; for (int i = 0; i < n; i++) a[i] = "F" + i + "=V" + (i * 7 % 100) + ";"; return a; }

    // ---- ORIGINAL: '+' per field, ticket String, then synchronized append to shared StringBuffer
    static CharSequence original(String[] f, int tickets) {
        StringBuffer log = new StringBuffer();
        for (int t = 0; t < tickets; t++) { String s = ""; for (String x : f) s = s + x; log.append(s).append('\n'); }
        return log;
    }
    // ---- NAIVE FIX: only swap class (new StringBuilder per ticket, toString, shared StringBuffer)
    static CharSequence naive(String[] f, int tickets) {
        StringBuffer log = new StringBuffer();
        for (int t = 0; t < tickets; t++) { StringBuilder b = new StringBuilder(); for (String x : f) b.append(x); log.append(b.toString()).append('\n'); }
        return log;
    }
    // ---- REDESIGN: exploit amortised O(1) append + known final size.
    //  * size every buffer once from the field lengths (no re-growth / copying)
    //  * write fields straight into a per-thread chunk (no per-ticket String, no per-append lock)
    //  * publish the chunk to the shared log with ONE lock acquisition per 500 tickets
    static final int CHUNK = 500;
    static void worker(String[] f, int tickets, StringBuilder shared) {
        int ticketLen = 1; for (String x : f) ticketLen += x.length();
        StringBuilder chunk = new StringBuilder(ticketLen * Math.min(CHUNK, tickets));
        for (int t = 0; t < tickets; t++) {
            for (String x : f) chunk.append(x);
            chunk.append('\n');
            if ((t + 1) % CHUNK == 0) { synchronized (shared) { shared.append(chunk); } chunk.setLength(0); }
        }
        if (chunk.length() > 0) synchronized (shared) { shared.append(chunk); }
    }
    static CharSequence redesign(String[] f, int tickets) {
        int ticketLen = 1; for (String x : f) ticketLen += x.length();
        StringBuilder shared = new StringBuilder(ticketLen * tickets);
        worker(f, tickets, shared); return shared;
    }

    interface Job { CharSequence run(String[] f, int tickets); }
    static long sink;

    static void measure(String label, Job j, String[] f, int tickets, int runs, int[] hash) {
        sink += j.run(f, Math.min(tickets, 200)).length();                 // warm-up
        sink += j.run(f, tickets).length();
        double ms = 0; long al = 0; CharSequence last = null;
        for (int r = 0; r < runs; r++) {
            long a0 = alloc(), t0 = System.nanoTime(); last = j.run(f, tickets);
            ms += (System.nanoTime() - t0) / 1e6; al += alloc() - a0;
        }
        hash[0] = last.toString().hashCode();
        System.out.printf("%-34s %10.2f ms %12.1f MB alloc   log hash %d%n", label, ms / runs, al / runs / 1048576.0, hash[0]);
    }

    public static void main(String[] a) throws Exception {
        System.out.println("Java " + System.getProperty("java.version") + "  (average of 5 runs after warm-up)");
        int[][] wl = {{10_000, 50}, {20, 4000}};
        for (int[] w : wl) {
            System.out.println("\n== " + w[0] + " tickets x " + w[1] + " fields ==");
            String[] f = f(w[1]); int[] h1 = new int[1], h2 = new int[1], h3 = new int[1];
            measure("Original  ('+' + StringBuffer log)", Q7::original, f, w[0], 5, h1);
            measure("Naive fix (StringBuilder per ticket)", Q7::naive, f, w[0], 5, h2);
            measure("Redesign  (sized chunk, batched lock)", Q7::redesign, f, w[0], 5, h3);
            System.out.println("Identical output in all three: " + (h1[0] == h2[0] && h2[0] == h3[0]));
        }
        // multithreaded: 4 booking threads, shared log
        System.out.println("\n== 4 threads x 2,500 tickets x 50 fields writing to ONE shared log ==");
        String[] f = f(50); int per = 2500;
        int ticketLen = 1; for (String x : f) ticketLen += x.length();
        for (int round = 1; round <= 3; round++) {
            StringBuilder shared = new StringBuilder(); AtomicLong al = new AtomicLong();
            Thread[] ts = new Thread[4]; long t0 = System.nanoTime();
            for (int i = 0; i < 4; i++) { ts[i] = new Thread(() -> { long a0 = alloc(); worker(f, per, shared); al.addAndGet(alloc() - a0); }); ts[i].start(); }
            for (Thread t : ts) t.join();
            System.out.printf("round %d: log length %d (expected %d) -> %s | %.2f ms | %.1f MB alloc%n", round, shared.length(), 4L * per * ticketLen,
                shared.length() == 4L * per * ticketLen ? "no lost writes" : "LOST WRITES", (System.nanoTime() - t0) / 1e6, al.get() / 1048576.0);
        }
        System.out.println("(checksum " + sink + ")");
    }
}
