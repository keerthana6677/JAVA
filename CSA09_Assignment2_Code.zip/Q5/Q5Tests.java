import java.util.*;
import java.util.stream.*;

public class Q5Tests {
    record Team(String name, int points, int goalDiff) {
        public String toString() { return name + "(" + points + "," + goalDiff + ")"; }
    }
    // Reusable generic component: bounded type + wildcards
    static class Leaderboard<T> {
        private final List<T> items = new ArrayList<>();
        private final Comparator<? super T> order;
        Leaderboard(Comparator<? super T> order) { this.order = Objects.requireNonNull(order); }
        void addAll(Collection<? extends T> more) { items.addAll(more); }      // producer wildcard
        List<T> ranking() { List<T> c = new ArrayList<>(items); c.sort(order); return c; }
        List<T> top(int k) { return ranking().subList(0, Math.min(k, items.size())); }
    }
    // natural-order variant using a bounded type
    static <T extends Comparable<? super T>> List<T> rankNatural(Collection<? extends T> c) { List<T> l = new ArrayList<>(c); Collections.sort(l); return l; }

    static final Comparator<Team> CORRECT = Comparator.comparingInt(Team::points).reversed()
        .thenComparing(Comparator.comparingInt(Team::goalDiff).reversed()).thenComparing(Team::name);
    // faulty 1: subtraction (overflows) 
    static final Comparator<Team> SUBTRACT = (a, b) -> { int c = b.points() - a.points(); if (c != 0) return c; c = b.goalDiff() - a.goalDiff(); return c != 0 ? c : a.name().compareTo(b.name()); };
    // faulty 2: ignores the name tie-breaker
    static final Comparator<Team> NO_NAME = Comparator.comparingInt(Team::points).reversed().thenComparing(Comparator.comparingInt(Team::goalDiff).reversed());

    static List<Team> sorted(List<Team> in, Comparator<Team> c) { List<Team> l = new ArrayList<>(in); l.sort(c); return l; }

    // brute-force check of the principle: antisymmetry, transitivity, consistency of equal items
    static String verify(Comparator<Team> c, List<Team> ts) {
        int anti = 0, trans = 0, eq = 0;
        for (Team a : ts) for (Team b : ts) {
            if (Integer.signum(c.compare(a, b)) != -Integer.signum(c.compare(b, a))) anti++;
            for (Team d : ts) {
                if (c.compare(a, b) < 0 && c.compare(b, d) < 0 && !(c.compare(a, d) < 0)) trans++;
                if (c.compare(a, b) == 0 && Integer.signum(c.compare(a, d)) != Integer.signum(c.compare(b, d))) eq++;
            }
        }
        return "antisymmetry violations=" + anti + ", transitivity violations=" + trans + ", equal-items violations=" + eq;
    }

    public static void main(String[] a) {
        System.out.println("=== DATA SET 1: several ties at every level ===");
        List<Team> d1 = List.of(new Team("Panthers", 9, 4), new Team("Eagles", 9, 6), new Team("Cobras", 6, 1), new Team("Bisons", 9, 4),
            new Team("Dragons", 6, 1), new Team("Aces", 6, 3), new Team("Falcons", 3, 0), new Team("Bulls", 9, 6));
        Leaderboard<Team> lb = new Leaderboard<>(CORRECT); lb.addAll(d1);
        System.out.println("Ranking : " + lb.ranking());
        System.out.println("Top 3   : " + lb.top(3));
        System.out.println("Original input order unchanged: " + d1);

        System.out.println("\n=== DATA SET 2: designed to break faulty comparators ===");
        List<Team> d2 = List.of(new Team("Zeta", 5, 2), new Team("Alpha", 5, 2), new Team("Mid", 3, 0));
        List<Team> d2r = new ArrayList<>(d2); Collections.reverse(d2r);
        System.out.println("Correct, input order 1 : " + sorted(d2, CORRECT));
        System.out.println("Correct, input reversed: " + sorted(d2r, CORRECT));
        List<Team> ov2 = List.of(new Team("Huge", 2_000_000_000, 0), new Team("Tiny", -2_000_000_000, 0));
        System.out.println("Overflow test, input " + ov2);
        System.out.println("  Correct comparator     : " + sorted(ov2, CORRECT));
        System.out.println("  Subtraction comparator : " + sorted(ov2, SUBTRACT) + "   <- Tiny ranked above Huge (int overflow)");
        System.out.println("No-name comparator, input order 1 : " + sorted(d2, NO_NAME));
        System.out.println("No-name comparator, input reversed: " + sorted(d2r, NO_NAME) + "   <- Zeta/Alpha order depends on input, not on the rule");

        System.out.println("\n=== Brute-force check of the principle on 300 random teams (27,000,000 triples) ===");
        Random r = new Random(3); List<Team> rs = new ArrayList<>();
        for (int i = 0; i < 300; i++) rs.add(new Team("T" + r.nextInt(40), r.nextInt(6) * 3, r.nextInt(5) - 2));
        System.out.println("CORRECT : " + verify(CORRECT, rs));
        List<Team> ov = new ArrayList<>(); for (int i = 0; i < 300; i++) ov.add(new Team("T" + i, (i % 3 - 1) * 1_500_000_000, 0));
        System.out.println("SUBTRACT on large points: " + verify(SUBTRACT, ov));

        System.out.println("\n=== Alternative: three stable sorts (name, then goalDiff, then points) ===");
        List<Team> s3 = new ArrayList<>(d1);
        s3.sort(Comparator.comparing(Team::name)); s3.sort(Comparator.comparingInt(Team::goalDiff).reversed()); s3.sort(Comparator.comparingInt(Team::points).reversed());
        System.out.println("3 stable sorts : " + s3);
        System.out.println("Chained sort   : " + sorted(d1, CORRECT));
        System.out.println("Same result    : " + s3.equals(sorted(d1, CORRECT)));

        System.out.println("\n=== Time: one chained sort vs three stable sorts (200,000 teams, best of 5, ms) ===");
        List<Team> big = new ArrayList<>(); Random q = new Random(9);
        for (int i = 0; i < 200_000; i++) big.add(new Team("T" + q.nextInt(5000), q.nextInt(30), q.nextInt(20) - 10));
        double bc = 1e18, b3 = 1e18;
        for (int k = 0; k < 6; k++) {
            List<Team> x = new ArrayList<>(big); long t = System.nanoTime(); x.sort(CORRECT); if (k > 0) bc = Math.min(bc, (System.nanoTime() - t) / 1e6);
            List<Team> y = new ArrayList<>(big); t = System.nanoTime();
            y.sort(Comparator.comparing(Team::name)); y.sort(Comparator.comparingInt(Team::goalDiff).reversed()); y.sort(Comparator.comparingInt(Team::points).reversed());
            if (k > 0) b3 = Math.min(b3, (System.nanoTime() - t) / 1e6);
        }
        System.out.printf("1 sort with comparator chain: %.1f ms | 3 stable sorts: %.1f ms%n", bc, b3);
    }
}
