import java.lang.management.ManagementFactory;
import java.util.*;
import java.util.function.Function;

public class Q1 {
    static final com.sun.management.ThreadMXBean TB =
        (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();
    @SuppressWarnings("deprecation") static long alloc() { return TB.getThreadAllocatedBytes(Thread.currentThread().getId()); }
    static long usedMB() { Runtime r = Runtime.getRuntime(); return (r.totalMemory() - r.freeMemory()) >> 20; }
    static long sink;

    static String[] fields(int n) {
        String[] f = new String[n];
        for (int i = 0; i < n; i++) f[i] = "F" + i + "=V" + (i * 7 % 100) + ";";
        return f;
    }
    static String plus(String[] f)   { String s = ""; for (String x : f) s = s + x; return s; }
    static String sb(String[] f)     { StringBuilder b = new StringBuilder(); for (String x : f) b.append(x); return b.toString(); }
    static String sbuf(String[] f)   { StringBuffer b = new StringBuffer(); for (String x : f) b.append(x); return b.toString(); }
    static String join(String[] f)   { return String.join("", f); }
    static String joiner(String[] f) { StringJoiner j = new StringJoiner(""); for (String x : f) j.add(x); return j.toString(); }
    static String fmt(String[] f)    { StringBuilder b = new StringBuilder(); for (String x : f) b.append(String.format("%s", x)); return b.toString(); }

    static void run(String label, Function<String[], String> fn, int tickets, int nf, int runs) {
        String[] f = fields(nf);
        for (int t = 0; t < tickets; t++) sink += fn.apply(f).length();     // warm-up
        System.gc();
        long before = usedMB();
        double totalMs = 0; long totalAlloc = 0;
        for (int r = 0; r < runs; r++) {
            long a0 = alloc(), t0 = System.nanoTime();
            for (int t = 0; t < tickets; t++) sink += fn.apply(f).length();
            totalMs += (System.nanoTime() - t0) / 1e6;
            totalAlloc += alloc() - a0;
        }
        long after = usedMB();
        double ms = totalMs / runs;
        System.out.printf("%-14s %10.2f ms %10.3f us/ticket %10.1f MB alloc  heap %d->%d MB%n",
            label, ms, ms * 1000 / tickets, totalAlloc / runs / 1048576.0, before, after);
    }

    static void workload(String name, int tickets, int nf, int runs) {
        System.out.println("\n== " + name + ": " + tickets + " ticket(s) x " + nf + " fields, avg of " + runs + " runs ==");
        run("String +",       Q1::plus,   tickets, nf, runs);
        run("StringBuilder",  Q1::sb,     tickets, nf, runs);
        run("StringBuffer",   Q1::sbuf,   tickets, nf, runs);
        run("String.join",    Q1::join,   tickets, nf, runs);
        run("StringJoiner",   Q1::joiner, tickets, nf, runs);
        if (nf <= 50) run("String.format", Q1::fmt, tickets, nf, runs);
    }

    static void growth() {
        System.out.println("\n== Growth: ONE ticket, n fields (avg of 5 runs, ms) ==");
        System.out.printf("%8s %12s %12s %8s%n", "n", "String +", "StringBuilder", "ratio");
        for (int n : new int[]{2000, 4000, 8000, 16000, 32000}) {
            String[] f = fields(n);
            for (int w = 0; w < 3; w++) { sink += plus(f).length(); sink += sb(f).length(); }
            double p = 0, s = 0;
            for (int r = 0; r < 5; r++) {
                long t0 = System.nanoTime(); sink += plus(f).length(); p += (System.nanoTime() - t0) / 1e6;
                t0 = System.nanoTime(); sink += sb(f).length(); s += (System.nanoTime() - t0) / 1e6;
            }
            System.out.printf("%8d %12.3f %12.3f %7.0fx%n", n, p / 5, s / 5, p / s);
        }
    }

    static void threads() throws Exception {
        System.out.println("\n== Shared log: 4 threads x 500,000 appends (expected length 2000000) ==");
        for (int trial = 1; trial <= 5; trial++) {
            StringBuilder b1 = new StringBuilder(); StringBuffer b2 = new StringBuffer();
            String r1 = go(b1::append), r2 = go(b2::append);
            System.out.printf("trial %d  StringBuilder: %-45s StringBuffer: %s%n", trial,
                r1.isEmpty() ? "length=" + b1.length() : r1, "length=" + b2.length());
        }
    }
    interface App { void add(String s); }
    static String go(App app) throws Exception {
        final String[] err = {""};
        Thread[] ts = new Thread[4];
        java.util.concurrent.CountDownLatch go = new java.util.concurrent.CountDownLatch(1);
        for (int i = 0; i < 4; i++) {
            ts[i] = new Thread(() -> { try { go.await(); for (int k = 0; k < 500000; k++) app.add("x"); }
                catch (Throwable e) { err[0] = e.getClass().getSimpleName(); } });
            ts[i].start();
        }
        go.countDown();
        for (Thread t : ts) t.join();
        return err[0].isEmpty() ? "" : "EXCEPTION " + err[0];
    }

    public static void main(String[] a) throws Exception {
        System.out.println("Java " + System.getProperty("java.version"));
        workload("Workload A (short ticket)", 100000, 10, 5);
        workload("Workload B (bulk day)", 10000, 50, 5);
        workload("Workload C (group booking, own design)", 20, 4000, 3);
        growth();
        threads();
        System.out.println("(checksum " + sink + ")");
    }
}
