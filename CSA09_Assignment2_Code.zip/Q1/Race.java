public class Race {
    public static void main(String[] a) throws Exception {
        for (int trial = 1; trial <= 5; trial++) {
            StringBuilder b = new StringBuilder();
            Thread[] ts = new Thread[4];
            final String[] err = {""};
            for (int i = 0; i < 4; i++) {
                ts[i] = new Thread(() -> { try { for (int k = 0; k < 500000; k++) b.append("x"); }
                    catch (Throwable e) { err[0] = e.getClass().getSimpleName(); } });
            }
            for (Thread t : ts) t.start();
            for (Thread t : ts) t.join();
            System.out.println("trial " + trial + " length=" + b.length() + " " + err[0]);
        }
    }
}
