import java.util.*;

public class Q4 {
    static long sink;
    record Med(String code, int stock) {}

    static double ms(Runnable r) { r.run(); double b = 1e18;
        for (int i = 0; i < 3; i++) { long t = System.nanoTime(); r.run(); b = Math.min(b, (System.nanoTime() - t) / 1e6); } return b; }

    static String report(Collection<Med> c) { StringBuilder sb = new StringBuilder(); for (Med m : c) sb.append(m.code()).append(':').append(m.stock()).append('\n'); return sb.toString(); }

    public static void main(String[] args) {
        System.out.println("Java " + System.getProperty("java.version") + "  (ms, best of 3)  100,000 random lookups per structure");
        // Part 1: correctness of order on a tiny sample
        String[] sample = {"M300", "M100", "M200", "M050"};
        Map<String, Med> h = new HashMap<>(), t = new TreeMap<>(), l = new LinkedHashMap<>(); Map<String, Med> ht = new Hashtable<>();
        int i = 1; for (String c : sample) { Med m = new Med(c, i++ * 10); h.put(c, m); t.put(c, m); l.put(c, m); ht.put(c, m); }
        System.out.println("\nInsertion order used : " + Arrays.toString(sample));
        System.out.println("HashMap iteration    : " + h.keySet());
        System.out.println("TreeMap iteration    : " + t.keySet() + "   <- code order");
        System.out.println("LinkedHashMap        : " + l.keySet() + "   <- insertion order");
        System.out.println("Hashtable iteration  : " + ht.keySet());

        // Part 2: measurements
        int[] sizes = {1_000, 10_000, 100_000};
        Random rnd = new Random(42);
        for (int n : sizes) {
            List<String> codes = new ArrayList<>();
            for (int k = 0; k < n; k++) codes.add(String.format("MED%07d", k * 7 + 1));
            Collections.shuffle(codes, rnd);                      // added in random code order
            String[] probe = new String[100_000];
            for (int k = 0; k < probe.length; k++) probe[k] = codes.get(rnd.nextInt(n));

            System.out.println("\n== n = " + n + " medicines ==");
            System.out.printf("%-14s %10s %14s %16s %16s %s%n", "Structure", "put n (ms)", "100k get (ms)", "ns / lookup", "insertion-order", "code-order report (ms)");
            for (String kind : new String[]{"HashMap", "TreeMap", "LinkedHashMap", "Hashtable"}) {
                java.util.function.Supplier<Map<String, Med>> mk = () -> switch (kind) {
                    case "HashMap" -> new HashMap<>(); case "TreeMap" -> new TreeMap<>();
                    case "LinkedHashMap" -> new LinkedHashMap<>(); default -> new Hashtable<>(); };
                double put = ms(() -> { Map<String, Med> m = mk.get(); for (String c : codes) m.put(c, new Med(c, 5)); sink += m.size(); });
                Map<String, Med> m = mk.get(); for (String c : codes) m.put(c, new Med(c, 5));
                double get = ms(() -> { long s = 0; for (String p : probe) s += m.get(p).stock(); sink += s; });
                double addedOrder = ms(() -> sink += report(m.values()).length());
                // code-order report: TreeMap is naturally sorted; others must sort first
                double codeOrder;
                if (kind.equals("TreeMap")) codeOrder = ms(() -> sink += report(m.values()).length());
                else codeOrder = ms(() -> { List<Med> v = new ArrayList<>(m.values()); v.sort(Comparator.comparing(Med::code)); sink += report(v).length(); });
                String insOK = kind.equals("LinkedHashMap") ? "matches" : "does NOT match";
                System.out.printf("%-14s %10.2f %14.2f %16.1f %16s %.2f  (%s)%n", kind, put, get, get * 1e6 / 100_000, insOK + " (" + String.format("%.2f", addedOrder) + " ms)", codeOrder,
                    kind.equals("TreeMap") ? "no extra sort" : "extra sort needed");
            }
            // sorted array + binary search
            Med[] arr = new Med[n]; for (int k = 0; k < n; k++) arr[k] = new Med(codes.get(k), 5);
            double build = ms(() -> { Med[] c = arr.clone(); Arrays.sort(c, Comparator.comparing(Med::code)); sink += c.length; });
            Med[] sorted = arr.clone(); Arrays.sort(sorted, Comparator.comparing(Med::code));
            Med[] sortedKeysHolder = sorted;
            double bs = ms(() -> { long s = 0; for (String p : probe) { int ix = Arrays.binarySearch(sortedKeysHolder, new Med(p, 0), Comparator.comparing(Med::code)); s += ix; } sink += s; });
            double ins = ms(() -> { Med[] a = Arrays.copyOf(sortedKeysHolder, n + 1000); int sz = n;
                for (int q = 0; q < 1000; q++) { Med nm = new Med(String.format("MED%07d", rnd.nextInt(n * 7)), 1);
                    int pos = Arrays.binarySearch(a, 0, sz, nm, Comparator.comparing(Med::code)); if (pos < 0) pos = -pos - 1;
                    System.arraycopy(a, pos, a, pos + 1, sz - pos); a[pos] = nm; sz++; } sink += sz; });
            System.out.printf("%-14s build+sort %.2f ms | 100k binarySearch %.2f ms (%.1f ns each) | 1,000 sorted inserts %.2f ms | code-order report = free (already sorted)%n",
                "sorted array", build, bs, bs * 1e6 / 100_000, ins);
        }
        System.out.println("(checksum " + sink + ")");
    }
}
