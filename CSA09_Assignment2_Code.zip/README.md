# CSA09 Assignment 2 (CO2)

- Name: ____________________
- Register number: ____________________
- Java version: OpenJDK 21 (outputs in this repo were captured with 21.0.12)

## How to run
Single-file programs (JDK 11+):  `java Q1.java`
Programs with several top-level classes where the main class is not first (Q3 Attendance, Q5 LeaderboardDemo, Q6 Triage):
`javac Attendance.java && java Attendance`

| Task | Run | Result |
|---|---|---|
| Q1 | `cd Q1 && java Q1.java` | '+' is O(n^2): 120x slower and 400x more memory on 4,000-field tickets; StringBuilder for tickets, StringBuffer for shared log |
| Q2 | `cd Q2 && java Q2.java` | ArrayList fine for append/get/iterate; ArrayDeque for the Up Next queue |
| Q3 | `cd Q3/before && javac Attendance.java && java Attendance` (prints 3), then `cd ../after` (prints 2); `cd ../experiment && java Q3Experiments.java` | hashCode must be consistent with equals |
| Q4 | `cd Q4 && java Q4.java` | LinkedHashMap for lookup + added-order report; sort for the nightly code-order report |
| Q5 | `cd Q5 && javac LeaderboardDemo.java && java LeaderboardDemo`; `java Q5Tests.java` | Comparator chain; Bisons above Panthers by name |
| Q6 | `cd Q6 && javac Triage.java && java Triage`; `java Q6Study.java` | PriorityQueue with arrival counter; aging key avoids starvation |
| Q7 | `cd Q7 && java Q7.java` | Redesign of Q1: 97% less allocation, 6.4x faster on 10,000 tickets |
